function [NormalPop, a] = Normalization(PopObj, K)
    [N, M] = size(PopObj);
    % Detect the extreme points
    Extreme = zeros(1, M);
    w = zeros(M) + 1e-6 + eye(M);
    for i = 1 : M
        [~, Extreme(i)] = min(max(PopObj./repmat(w(i, :), N, 1), [], 2));
    end
    % Calculate the intercepts of the hyperplane constructed by the extreme
    % points and the axes
    Hyperplane = PopObj(Extreme, :)\ones(M, 1);
    a = 1./Hyperplane;
    if any(isnan(a))
        a = max(PopObj, [], 1)';
    end
    % Normalization
    NormalPop = PopObj./repmat(a', N, 1);
    a = a';


end