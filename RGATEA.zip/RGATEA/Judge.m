function [Pbetter, value] = Judge(Pone, Ptwo, W, vectorNum, maxtheta, maxrefer, Fmin, PBI, K)
    PoneObj = Pone.objs;
    PtwoObj = Ptwo.objs;
%  
%     PoneObj = (K .* PoneObj)  - Fmin;
%     PtwoObj = (K .* PtwoObj)  - Fmin;
    
    V1 = W(vectorNum, :);
    


    CthetaOne = 1 - pdist2(PoneObj, V1, 'cosine');
    d_1 = sqrt(sum(PoneObj .^ 2, 2)).* CthetaOne;
    d_2 = sqrt(sum(PoneObj .^ 2, 2)).*sqrt(1 - CthetaOne.^2);
    thetaOne = K * d_1 + PBI * d_2;

    C = 1 - pdist2(PtwoObj, V1, 'cosine');
    d1 = sqrt(sum(PtwoObj .^ 2, 2)).* C;
    d2 = sqrt(sum(PtwoObj .^ 2, 2)).*sqrt(1 - C.^2);
    newtheta = K * d1 + PBI * d2;

    maxtheta = thetaOne + maxtheta;

    C = size(PoneObj, 2);
    flagOne = 1;
    flagTwo = 1;

    %% Pone 支配 Ptwo
    for one = 1 : C
        if PtwoObj(1, one) < PoneObj(1, one)
            flagOne = 0;
            break;
        end
    end

    %% Ptwo 支配 Pone
    for two = 1 : C
        if PoneObj(1,two) < PtwoObj(1, two)
            flagTwo = 0;
            break;
        end
    end
    %% judge
    if flagOne 
        Pbetter = Pone;
        value = 0;

    elseif flagTwo
        Pbetter = Ptwo;
        if newtheta < thetaOne
            value = 1;
        elseif newtheta <= maxtheta
            value = 2;
        else
            value = 0;
        end

    else

        if thetaOne < newtheta
            Pbetter = Pone;
            if newtheta <= maxtheta
                value = 1;
            else
                value = 2;
            end
            
        else
            Pbetter = Ptwo;
            value = 1;
        end
    end

end