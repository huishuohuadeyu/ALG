classdef RGATEAonly < ALGORITHM
% <multi/many> <real/integer/label/binary/permutation> <constrained/none>
    methods
        function main(Algorithm, Problem)
  
            alpha = 2;

            beta  = 5;


            K = 1;
            PBI  = 5;

            %% Generate the weight vectors
            [W, Problem.N] = UniformPoint(Problem.N, Problem.M);
            T = ceil(Problem.N / 10);

            %% Detect the neighbours
            B = pdist2(W, W);
            [thetavalue, B] = sort(B, 2);
            B = B(:, 1 : T);

            %% Calculate the min theta
            for m = 1 : Problem.N
%                 mtheta(m) = (thetavalue(1, 1));
                mtheta(m) = sum(thetavalue(m, 1:T)) / T;
                mtheta(m) = alpha * mtheta(m);
            end
            
            %% Generate random population
            Population = Problem.Initialization();
            PopObj = Population.objs;
            [N, M]  = size(PopObj);
            
            %% 关系二的关联
            % 归一化之后，进行关联，列是PopObj, 行是W
            NW = size(W, 1);
            Cosine = 1 - pdist2(PopObj, W, 'cosine');
            theta1 = repmat(sqrt(sum(PopObj .^ 2, 2)), 1, NW).*Cosine;
            theta2 = repmat(sqrt(sum(PopObj .^ 2, 2)), 1, NW).*sqrt(1-Cosine.^2);
%             theta = theta2;
            theta = theta1 + PBI * theta2;
            theta = theta';
            for k = 1 : Problem.N
                [vtheta(k), vi(k)] = min(theta(k, :));
                theta(:, vi(k)) = 999999;
            end

            rlist = vi;
            I = 1 : N;
            rtwolist = [I; vi; vtheta]; % 个体 向量 值
            

            [~, eachrlist] = sort(vi);
            
            
            %% Optimization
            
            while Algorithm.NotTerminated(Population)
                %% 归一化
                PopObj = Population.objs;
                
                if Problem.FE > 1 * Problem.maxFE 
                    nan = 0;
                else
                    if ~mod(ceil(Problem.FE / Problem.N), ceil( 0.1 * Problem.maxFE / Problem.N))
                        
                            PBI  = PBI + beta * PBI;
    
                            W(1:Problem.N,:) = ReferenceVectorAdaptation(Population.objs,W);
    
                            %% 关系二的关联
                            Cosine = 1 - pdist2(PopObj, W, 'cosine');
                            theta1 = repmat(sqrt(sum(PopObj .^ 2, 2)), 1, NW).*Cosine;
                            theta2 = repmat(sqrt(sum(PopObj .^ 2, 2)), 1, NW).*sqrt(1-Cosine.^2);
            %                         theta = theta2;
                            theta = theta1 + PBI * theta2;
                            theta = theta';
                            for k = 1 : Problem.N
                                [vtheta(k), vi(k)] = min(theta(k, :));
                                theta(:, vi(k)) = 999999;
                            end
                            rlist = vi;
                            I = 1 : N;
                            rtwolist = [I; vi; vtheta]; % 个体 向量 值            
                            [~, eachrlist] = sort(vi);
    
                   end
  
                end
                
      

                %% Set the update flag vector
                flag = true(1, Problem.N);

               
                %% Associate each solution with one reference vector
                % Calculate the distance of each solution to each reference vector

                Cosine = 1 - pdist2(PopObj, W, 'cosine');
                Distance = repmat(sqrt(sum(PopObj .^ 2, 2)), 1, NW).*sqrt(1-Cosine.^2);

                Distance = Distance';

                % 关系一，个体对向量的关联,pj是索引
                [d, pj] = min(Distance, [], 1);

                % referlist是关系一对应表
                % 个体，向量，距离
                referlist = [pj; d];

                

                %% Choose the parents
          
                for i = 1 : Problem.N
                    PopObj = Population.objs;
                    a = ones(1, M);

%                     parentsone = i;

                    if flag(i)
                        parentsone = i;
                    else
                        continue;
                    end

                    cv = referlist(1, parentsone);
                    neighbours = B(cv, :);

                    count1 = 0;
                    for t = 1 : N
                        if ismember(referlist(1, t), neighbours)
                            count1 = count1 + 1;
                            NBour(count1) = t; %#ok<AGROW> 
                        end
                    end


                    if rand() <= 0.3

                        randP = randperm(N);
                        parentstwo = randP(1);
                  
                    else

                        randP = NBour(1, randperm(size(NBour, 2)));
                        parentstwo = randP(1);

                    end

                   
               
                    dv1 = rlist(parentsone);
                    
                    C1 = 1 - pdist2(PopObj, W(dv1, :),'cosine');
                    r1 = sqrt(sum(PopObj .^ 2, 2)).*C1;
                    r2 = sqrt(sum(PopObj .^ 2, 2)).*sqrt(1-C1.^2);
                    [~, realP1] = min(K * r1 + PBI * r2);
%                     [~, realP1] = min(r2);


                    MatingPool = [realP1, parentstwo];
                    offspring = OperatorGAhalf(Problem, Population(MatingPool));

                    %% 更新个体
                    Fmin = zeros(Problem.M);
                    
                    %% 计算最小值以及其最近个体
                    [~, Target] = UpdateLeader(Problem, Population, PopObj, NBour,PBI, K);
                    Target = Target(2, 1);

                    [Population, ~, flag] = ...
                        Updataonly(Problem, Population, PopObj, parentsone, offspring(1), Target, realP1, W, dv1, ...
                        a, Fmin, flag, eachrlist, rlist, mtheta(parentsone), PBI, K);

                    
                end   

            end

        end

    end

end
