function [FLAG, Population, PopObj, flag] = DealTemp(Population, PopObj, parent, offspring, W, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K)
    FLAG = true;    
    tempoffobj = offspring.obj;
%     tempoffobj = (tempoffobj) ./ maxrefer;
    CT = 1 - pdist2(tempoffobj, W, 'cosine');
    t1 = sqrt(sum(tempoffobj .^ 2, 2)).*CT;
    t2 = sqrt(sum(tempoffobj .^ 2, 2)).*sqrt(1-CT.^2);

    [~, vectorNum] = min(K * t1 + PBI * t2);
    
    target = eachrlist(vectorNum);
    if target ~= parent
        [result, key] = Judge(Population(target), offspring, W, rlist(target), mtheta, maxrefer, Fmin, PBI, K);
        if result == offspring && key == 1 
            Population(target) = offspring;
            flag(target) = 0;
            FLAG = false;
        end 
    end
end