function [Population, PopObj, flag] = Updata(Problem, Population, PopObj, parent, offspring, Target, realP, W, vector, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K)
    [Pbetter, value] = Judge(Population(parent), offspring, W, vector, mtheta, maxrefer, Fmin, PBI, K);
    

    if Pbetter == offspring && value == 1 
        Population(parent) = offspring;
        flag(parent) = 0;

    elseif Pbetter == offspring && value ~= 1
        [F,Population, PopObj, flag] = DealTemp(Population, PopObj, parent, offspring, W, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K);

        if value == 0 && F
            TPool = [offspring, Population(Target), Population(parent)];

            Toffspring = TDE2(Problem, TPool);
            
            [Pbetter, Ovalue] = Judge(Population(parent), Toffspring, W, vector, mtheta, maxrefer, Fmin, PBI, K);

            if Pbetter == Toffspring && Ovalue == 1 
                Population(parent) = Toffspring;
                flag(parent) = 0;

            else
                [FLAG, Population, PopObj, flag] = DealTemp(Population, PopObj, parent, Toffspring, W, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K);
                
                if FLAG
                    if Pbetter == Toffspring && Ovalue ~= 0
                        Population(parent) = Toffspring; 
                        flag(parent) = 0;
                    end
                end
            end
                
            
           
        elseif value == 2 && F
            TPool =  [offspring, Population(Target)];

            Toffspring = TDE1(Problem, TPool);

            [Pbetter, Ovalue] = Judge(Population(parent), Toffspring, W, vector, mtheta, maxrefer, Fmin, PBI, K);

            if Pbetter == Toffspring && Ovalue == 1 
                Population(parent) = Toffspring;
                flag(parent) = 0;

            else 
                [FLAG, Population, PopObj, flag] = DealTemp(Population, PopObj, parent, Toffspring, W, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K);
                
                if FLAG
                    if Pbetter == Toffspring && Ovalue ~= 0
                        Population(parent) = Toffspring;                            
                        flag(parent) = 0;
                    else
                        Population(parent) = offspring;                            
                        flag(parent) = 0;
                    end
                end
            end
        end

    elseif Pbetter == Population(parent) && value ~= 0


            TPool = [offspring, Population(Target)];
            Toffspring = TDE1(Problem, TPool);
        
            [Pbetter, Pvalue] = Judge(Population(parent), Toffspring, W, vector, mtheta, maxrefer, Fmin, PBI, K);

            if Pbetter == Toffspring && Pvalue == 1 
                Population(parent) = Toffspring;
                flag(parent) = 0;

            else
                [FLAG, Population, PopObj, flag] = DealTemp(Population, PopObj, parent, Toffspring, W, maxrefer, Fmin, flag, eachrlist, rlist, mtheta, PBI, K);
                
                if FLAG
                    if Pbetter == Toffspring && Pvalue ~= 0
                        Population(parent) = Toffspring;                            
                        flag(parent) = 0;
                    end
                end
            end
                
    end
end