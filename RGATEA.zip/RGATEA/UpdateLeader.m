function [Z, temp] = UpdateLeader(Problem, Population, PopObj, NBour, PBI, K)
%     Z = min(Population.objs, [], 1); 
    Z = zeros(Problem.M);

%     Z = ones(Problem.M);

    temp = pdist2(PopObj(NBour, 1 : Problem.M), Z);

% 
%     Cosine = 1 - pdist2(PopObj(NBour, 1 : Problem.M), Z(1,:), 'cosine');
% 
%     theta1 = sqrt(sum(PopObj(NBour, 1 : Problem.M) .^ 2, 2)).*Cosine;
%     theta2 = sqrt(sum(PopObj(NBour, 1 : Problem.M), 2)).*sqrt(1-Cosine.^2);
%     
%     temp = theta1;
    temp = temp';

    temp(2, :) = NBour;
    temp = temp';

    temp = sortrows(temp, 1);
    temp = temp';
end